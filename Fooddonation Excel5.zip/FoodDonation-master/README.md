Food Donation

I have built an Android App named “Food Donation” as a part of my certification program in Android Development at the Code Louisville. The purpose of this app is to make food donation process easier, faster and convenient.

I have implemented below functionalities in this app.

•	Food donor and food shelter organizations can login/signup to this app.

•	Donor organizations can make a food donation post (contact information, approximate people based on food quantity, etc.).

•	Recipient organizations can also make a food request post (contact information, approximate people, etc.).

•	Both the donors and recipients can view the lists of available food donors and recipients.

•	After certain amount of time (24 hours in this project) the food post entries are automatically deleted from both donor and recipient lists.

•	I have used Parse.com as a Back End.


